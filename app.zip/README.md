# GitHub Actions Cert Prep

[![simple_workflow](https://github.com/timothywarner/github_actions/actions/workflows/simple.yml/badge.svg)](https://github.com/timothywarner/github_actions/actions/workflows/simple.yml)
